# 升级

## 提示升级 ##

当有新的更新时，wukong-robot 的后台会提示升级，询问你是否需要更新：

![](http://hahack-1253537070.file.myqcloud.com/images/update.jpg)

点击更新即可自动进入更新。

## 手动升级 ##

如果提示升级失败，可以尝试在 wukong-robot 的根目录手动执行以下命令，看看问题出在哪。

``` sh
python3 wukong.py update
```

